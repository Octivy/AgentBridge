$ErrorActionPreference = "Stop"

$targetBundle = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\CADTestCopilot.bundle"

if (-not (Test-Path $targetBundle)) {
    Write-Host "CAD Copilot is not installed for the current Windows user."
    exit 0
}

Remove-Item -LiteralPath $targetBundle -Recurse -Force
Write-Host "CAD Copilot has been removed. Restart AutoCAD to finish." -ForegroundColor Green
